package com.demo.repositories;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.demo.entities.Cart;
import com.demo.entities.Item;
import com.demo.entities.User;





@Repository
@CrossOrigin(origins = "http://localhost:4200")
public interface CartRepository extends JpaRepository<Cart, Long> {
	
	
	@Query("select  SUM(a.price) from Cart a where a.userId=: userId ")
	double getTotalAmountByUserId(@Param("userId") Long userId);
	
	
	@Query("Select a  from Cart a WHERE a.itemid=:itemId and  a.userid=:userId")
public Cart getCartByItemIdAnduserId(@Param("userId")List<Item> list, @Param("itemId")User user);
	
	@Modifying
    @Transactional
	@Query("DELETE  FROM Cart a WHERE a.id =:cartId   and a.userid=:userId")
	void deleteCartByIdAndUserId(@Param("userId")Long userId,@Param("cartId")  Long cartId);
	
	
	
	@Modifying
    @Transactional
	@Query("update Cart a set a.qty=:qty,a.price=:price WHERE a.id=:cartId")
	void updateQtyByCartId(@Param("cartId")Long cartId,@Param("price")double price,@Param("qty")Integer qty);
	
	
	
	
	
	
	
	

}
