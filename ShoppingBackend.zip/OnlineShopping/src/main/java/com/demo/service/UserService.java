package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.User;
import com.demo.repositories.UserRepository;

@Service
public class UserService {

	
	@Autowired
	private UserRepository userRepo;

	public User save(User u) throws Exception {
		String Email = u.getEmail();
		String pas = u.getPassword();
		User u1 = findByEmailAndPassword(Email, pas);
		if (u1 != null) {
			throw new Exception("User with" + Email +  "already exists");
		} else {

			return this.userRepo.save(u);
		}

	}
	
	
	public User findByEmailAndPassword(String email, String password) {
		return this.userRepo.findByEmailAndPassword(email, password);
	}
}
