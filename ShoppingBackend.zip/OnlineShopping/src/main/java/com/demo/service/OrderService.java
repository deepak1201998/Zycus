package com.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.Item;
import com.demo.entities.Order;
import com.demo.repositories.ItemRepository;
import com.demo.repositories.OrderRepository;



@Service
@Transactional
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;

	
	public Order save(Order e) {
		
		Order order = null;
		
		if(e.getOrderId() == null) {
			order = orderRepository.save(e);
		}
			
		
		
	return order ;
		
	}	
	
	
	public List<Order> getAllOrders(){
		return orderRepository.findAll();
	}
	
	public Order getOrder(Long oid) {
		Optional<Order> optOr =  orderRepository.findById(oid);
		Order e = null;
		if(optOr.isPresent())
			e = optOr.get();
		
		return e;
	}



	
	
}
