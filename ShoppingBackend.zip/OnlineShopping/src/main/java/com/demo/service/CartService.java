package com.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.demo.entities.Cart;
import com.demo.entities.Item;
import com.demo.entities.User;
import com.demo.repositories.CartRepository;


@Service
@Transactional
public class CartService {
	
	
	@Autowired
	private CartRepository cartRepository;
	
	
	   public Cart addCart(Cart u) throws Exception {
		
		Cart c = getCartByUserIdAndItemId(u.getUser(),u.getItems());
		if (c != null) {
			throw new Exception("Cart with this "+ u.getItems()+    "exist ");
		} else {

			return this.cartRepository.save(u);
		}

	}
	
	
	
	
   public Cart getCartByUserIdAndItemId(User user, List<Item> list ) {
	   
	   return cartRepository.getCartByItemIdAnduserId(list, user);

	   
   }

	public void updateQtyByCartId(long cartId, int qty, double price) throws Exception {
		cartRepository.updateQtyByCartId(cartId,price,qty);
	}

	
	
	public Boolean checkTotalAmountAgainstCart(double totalAmount,long userId) {
		double total_amount = cartRepository.getTotalAmountByUserId(userId);
		if(total_amount == totalAmount) {
			return true;
		}
		
		System.out.print("Error from request "+total_amount +" --db-- "+ totalAmount);
		return false;
	}
	
	public void removeCartByUserId(long itemId, long cartId) {
		cartRepository.deleteCartByIdAndUserId(cartId, itemId);
		
	}


	

	

}
