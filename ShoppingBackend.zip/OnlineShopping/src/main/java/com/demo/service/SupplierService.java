package com.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.Item;
import com.demo.entities.Suppliers;
import com.demo.repositories.ItemRepository;
import com.demo.repositories.SuppliersRepository;



@Service
@Transactional
public class SupplierService {
	
	@Autowired
	private SuppliersRepository  supplierRepository;

	
	public  Suppliers  save(Suppliers e) {
		
		Suppliers sup = null;
		
		if(e.getId() == null) {
			sup =  supplierRepository.save(e);
		}else {
			sup = getSuppliers(e.getId());
			
			if(sup!=null) {
				sup.setItemPrice(e.getItemPrice());
				sup.setSupplierName(e.getSupplierName());
			}
		}
		
		return sup;
		
	}	
	
	
	public List<Suppliers> getAllSuppliers(){
		return supplierRepository.findAll();
	}
	
	public Suppliers getSuppliers(Long id1) {
		Optional<Suppliers> optEmp =  supplierRepository.findById(id1);
		Suppliers e = null;
		if(optEmp.isPresent())
			e = optEmp.get();
		
		return e;
	}
	
	public Suppliers remove(Long id) {
		
		Suppliers e = getSuppliers(id);
		if(e!=null) {
			supplierRepository.delete(e);
		}
		return e;
	}
}
