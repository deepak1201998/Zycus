package com.demo.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name= "cart")
public class Cart {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long cartId;
	
	@NotNull
	private int qty;
	
	private double price;
	
	
	//mappings bidirectional
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id", nullable = false)
	private User user;
	
	
     //products
	@OneToMany(mappedBy ="cart", cascade = CascadeType.ALL)
	private List<Item> items = new ArrayList<Item>() ;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id", nullable = false)
	private Suppliers supplier;


	  

	public Cart(Long cartId, @NotNull int qty, double price, User user, List<Item> items, Suppliers supplier) {
		super();
		this.cartId = cartId;
		this.qty = qty;
		this.price = price;
		this.user = user;
		this.items = items;
		this.supplier = supplier;
	}




	public Long getCartId() {
		return cartId;
	}




	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}




	public int getQty() {
		return qty;
	}




	public void setQty(int qty) {
		this.qty = qty;
	}




	public double getPrice() {
		return price;
	}




	public void setPrice(double price) {
		this.price = price;
	}




	public User getUser() {
		return user;
	}




	public void setUser(User user) {
		this.user = user;
	}




	public List<Item> getItems() {
		return items;
	}




	public void setItems(List<Item> items) {
		this.items = items;
	}




	public Suppliers getSupplier() {
		return supplier;
	}




	public void setSupplier(Suppliers supplier) {
		this.supplier = supplier;
	}


	
	 
	
	
				

}
