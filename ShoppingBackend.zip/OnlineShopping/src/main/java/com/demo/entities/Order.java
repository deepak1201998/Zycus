package com.demo.entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "Orders")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
     private Long orderId;
	
	
	private Date billDate = new Date();
	@NotNull
	private double totalAmt;
	
      //mappings bidirectional
		@ManyToOne(cascade = CascadeType.ALL)
		@JoinColumn(name = "id", nullable = false)
		private User user;
		
	
	
	
	
	
	
	@OneToMany(mappedBy ="order", cascade = CascadeType.ALL)
	private List<Item> items = new ArrayList<Item>() ;






	public Order(Long orderId, Date billDate, @NotNull double totalAmt, User user, List<Item> items) {
		super();
		this.orderId = orderId;
		this.billDate = billDate;
		this.totalAmt = totalAmt;
		this.user = user;
		this.items = items;
	}






	public Long getOrderId() {
		return orderId;
	}






	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}






	public Date getBillDate() {
		return billDate;
	}






	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}






	public double getTotalAmt() {
		return totalAmt;
	}






	public void setTotalAmt(double totalAmt) {
		this.totalAmt = totalAmt;
	}






	public User getUser() {
		return user;
	}






	public void setUser(User user) {
		this.user = user;
	}






	public List<Item> getItems() {
		return items;
	}






	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	
	
	
	
	
}
