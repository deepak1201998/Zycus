package com.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

@Entity
public class Suppliers {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String supplierName;
	
	private double itemPrice;
	
	//mappings
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "itemId", nullable = false)
	private Item item;

	public Suppliers(Long id, String supplierName, double itemPrice) {
		super();
		this.id = id;
		this.supplierName = supplierName;
		this.itemPrice = itemPrice;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

	
	
	
	
	
	
	

	
	
}