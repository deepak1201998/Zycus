package com.demo.controller;

import java.util.List;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entities.Item;
import com.demo.entities.Suppliers;
import com.demo.service.ItemService;
import com.demo.service.SupplierService;


@RestController
@RequestMapping(path = "/api/suppliers")
public class SupplierController {
	
	@Autowired
	private SupplierService supplierService;
	
	@GetMapping(path = "/getAll")
	public List<Suppliers> getAll(){
		return this.supplierService.getAllSuppliers();
	}
	
	@GetMapping(path = "/{supplierId}")
	public Suppliers get(@PathVariable("supplierId") Long id) {
		return this.supplierService.getSuppliers(id);
	}
	
	@PostMapping(path = "")
	public Suppliers createSupplier(@RequestBody Suppliers sup) {
		
	//	return this.supplierService.save(item);
		
		
		if(sup.getSupplierName()!= null ) {
		return this.supplierService.save(sup);
				
		}
		else {
			throw new ValidationException("Suppliers cannot be created");
		}
	}
	
	
	@DeleteMapping(path = "/{supplierId}")
	public Suppliers delete(@PathVariable("suplierId") Long id) {
		return this.supplierService.remove(id);
		
		
		
		
	}
	
	@PutMapping(path = "/{supplierId}")
	public Suppliers updateSuppliers(@PathVariable("supplierId") Long id,  @RequestBody Suppliers sup) {
		
		Suppliers e = this.supplierService.getSuppliers(id);
		
		if(e!=null)
			e =  this.supplierService.save(sup);
		
		return e;
	}

}