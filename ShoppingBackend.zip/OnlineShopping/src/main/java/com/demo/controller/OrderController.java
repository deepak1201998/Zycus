package com.demo.controller;

import java.util.List;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entities.Item;
import com.demo.entities.Order;
import com.demo.service.ItemService;
import com.demo.service.OrderService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "/api/orders")
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	@GetMapping(path = "/getAll")
	public List<Order> getAll(){
		return this.orderService.getAllOrders();
	}
	
	@GetMapping(path = "/{orderId}")
	public Order get(@PathVariable("orderId") Long id) {
		return this.orderService.getOrder(id);
	}
	
	@PostMapping(path = "")
	public Order addOrder(@RequestBody Order order) {
		
		return this.orderService.save(order);
		
		
	
	}
	

		
		
	
	
	

}