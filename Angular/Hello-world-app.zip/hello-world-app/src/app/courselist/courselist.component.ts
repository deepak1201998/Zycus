import { Component, OnInit } from '@angular/core';
import { Course } from '../model/course.model';


@Component({
  selector: 'app-courselist',
  templateUrl: './courselist.component.html',
  styleUrls: ['./courselist.component.css']
})
export class CourselistComponent implements OnInit {


  public ourCourses: Course[];

  constructor() {
    

    this.ourCourses = [
      new Course(1, "Angular", "5 Days", "Vishal"),
      new Course(2, "React", "7 Days", "Vishal"),
      new Course(3, "Java", "15 Days", "Vishal"),
     ]
  }

  ngOnInit(): void {
  }

}
