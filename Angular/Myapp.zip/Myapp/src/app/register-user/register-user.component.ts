import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  public userForm: FormGroup;


  public get username(){
    return this.userForm.get('username')
  }

  public get password(){
    return this.userForm.get('password')
  }
  
  public get name(){
    return this.userForm.get('name')
  }
  

 
  constructor() {

    this.userForm = new FormGroup({
      username: new FormControl('', [Validators.required, Validators.minLength(6) ]),
      password: new FormControl('',[Validators.required, Validators.minLength(8) ]),
      name: new FormControl('', [Validators.required, Validators.minLength(6) ])
    })

  }


  handleSubmit() {
    console.log('form submitted...')
    console.log(this.userForm)
  }

  ngOnInit(): void {
  }

}